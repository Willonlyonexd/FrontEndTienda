export const GLOBAL={
    url:'http://localhost:3000',
    // url:'https://ecommerce-backend-production-bceb.up.railway.app',
     cliente_id:'Aat1GXTAFWbFCeoLvA1UdTnSM30Qew6V5Iu9_cV0ynQJApoY18Lsirfm-SaoA8kHOVeft7NiFz8VNqw_'
}